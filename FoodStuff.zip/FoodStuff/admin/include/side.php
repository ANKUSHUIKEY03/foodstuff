
  <div class="list-group">
    <a href="index.php" class="list-group-item list-group-item-action bg-info text-white" >Dashboard</a>
    <a href="employee.php" class="list-group-item list-group-item-action">employee</a>
    <a href="products.php" class="list-group-item list-group-item-action">Products</a>
    <a href="vendors.php" class="list-group-item list-group-item-action">Vendors</a>
    <a href="customers.php" class="list-group-item list-group-item-action">Customers</a>
  </div>
