<!DOCTYPE html>
<html>
<head>
	<title>
		About Us
	</title>
	<meta charset="utf-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="css/about_style.css">
	<link rel="stylesheet" href="bootstrap\bootstrap.min.css">
	    <link href="https://fonts.googleapis.com/css?family=Satisfy&display=swap" rel="stylesheet">

</head>
<body>
<!--About Us-->
<div class="team-section">
	<h1>Our Team</h1>
	<span class=border></span>
	<div class="ps">
		<a href="#p1"><img src="image/Mukesh.jpeg" alt=""></a>
		<a href="#p2"><img src="Image/ME.jpg" alt=""></a>
		<a href="#p3"><img src="image/sominto%20.jpg" alt="" style="margin-top:-40px"></a>
		<a href="#p4"><img src="image/rahul%20(2).jpg" alt=""></a>
	</div>

<div class="section " id="p1">
	<span class="name">Mukesh</span>
	<span class="border"></span>
	<p>
	Mukesh is Front-End developer & Market Manager.
	</p>

</div>
<div class="section " id="p2">
	<span class="name">Divya</span>
	<span class="border"></span>
	<p>
	 Divya Suman is a Web Developer and Designer in this project.
	</p>

</div>
<div class="section " id="p3">
	<span class="name">Sominto</span>
	<span class="border"></span>
	<p>
	Sominto is Front-End developer & Project Manager.	</p>

</div>
<div class="section " id="p4">
	<span class="name">Rahul</span>
	<span class="border"></span>
	<p>
	Rahul is Database designer & Backend support.	</p>

</div>





</div>
</body>
</html>
